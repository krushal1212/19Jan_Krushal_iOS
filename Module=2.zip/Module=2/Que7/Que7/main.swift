//
//  main.swift
//  Que7
//
//  Created by Krushal's Macbook on 26/02/23.
//

import Foundation


print("Enter your age : ")
var age=Int(readLine()!)!
print("Age is : ", age)

