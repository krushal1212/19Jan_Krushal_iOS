//
//  main.swift
//  Que15
//
//  Created by Krushal's Macbook on 28/02/23.
//

import Foundation

var arrySet = ["ID":"101","Name":"Krushal","City":"Rajkot"]
print(arrySet["ID"]!)

