//
//  main.swift
//  Que8
//
//  Created by Krushal's Macbook on 27/02/23.
//

import Foundation

print("Enter the value of A: ")
var a = Double(readLine()!)!
print("Enter the value of B: ")
var b = Double(readLine()!)!

var sum = a+b
print("Sum = \(sum)")

var sub = a-b
print("Sub = \(sub)")

var mul = a*b
print("Mul = \(mul)")

var div = a/b
print("Div = \(div)")

