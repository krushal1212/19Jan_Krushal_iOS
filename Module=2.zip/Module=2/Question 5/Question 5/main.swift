//
//  main.swift
//  Question 5
//

//

import Foundation

import Foundation

print("Enter value of a: ")
var a = Double(readLine()!)!
print("Enter value of b: ")
var b = Double(readLine()!)!

var sum = a+b
print("sum=\(sum)")

var sub = a-b
print("sub=\(sub)")

var mul = a*b
print("mul=\(mul)")

var div = a/b
print("Div=\(div)")
