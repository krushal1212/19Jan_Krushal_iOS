//
//  main.swift
//  Que14
//
//  Created by Krushal's Macbook on 28/02/23.
//

import Foundation

var setA: Set = ["A","B","C"]
var setB: Set = ["B","C","D"]

var setAorsetB = setA.union(setB)

print("\nunion is : ",setAorsetB)

var intersectionAorB = setA.intersection(setB)
print("\nIntersection is : ",intersectionAorB,"\n")


var set1: Set = ["AAA","BBB","CCC"]
var set2: Set = ["A","B","CCC"]

var AandB = set1.union(set2)
print(AandB)

var ABC = set1.intersection(set2)
print(ABC)
