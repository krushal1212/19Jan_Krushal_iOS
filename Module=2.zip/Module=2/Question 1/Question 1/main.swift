//
//  main.swift
//  Question 1
//
//

import Foundation

print("Enter your name : ")

var nm:String
nm=readLine()!

print("Name is : \(nm)")

