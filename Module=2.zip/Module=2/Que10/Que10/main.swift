//
//  main.swift
//  Que10
//
//  Created by Krushal's Macbook on 27/02/23.
//

import Foundation


print("Enter the value of A: ")
var a = Int(readLine()!)!

print("Enter the value of B: ")
var b = Int(readLine()!)!

print("Enter the value of C: ")
var c = Int(readLine()!)!

print("Enter the value of D: ")
var d = Int(readLine()!)!

if a>b && a>c && a>d
{
    print("A is max")
}
else if  b>a && b>c && b>d
{
    print("B is max")
}
else if c>a && c>b && c>d
{
    print("C is max")
}
else if d>a && d>b && d>c
{
    print("D is max")
}
