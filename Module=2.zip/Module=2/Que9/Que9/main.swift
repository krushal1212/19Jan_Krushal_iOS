//
//  main.swift
//  Que9
//
//  Created by Krushal's Macbook on 27/02/23.
//

import Foundation

var number = Int()
print(number)
