//
//  main.swift
//  Que17
//
//  Created by Krushal's Macbook on 28/02/23.
//

import Foundation

var array = Array<String>()
print("Enter number of loop value")
var n = Int(readLine()!)!

for i in 0..<n{
    print("Enter number of city")
    var city = readLine()!
    array.append(city)
}
print("City name:- \(array)")
