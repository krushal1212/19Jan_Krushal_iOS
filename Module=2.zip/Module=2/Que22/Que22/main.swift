//
//  main.swift
//  Que22
//
//  Created by Krushal's Macbook on 01/03/23.
//

import Foundation

var array = ["delta", "alpha", "bravo"]
array.sort()

print(array)

