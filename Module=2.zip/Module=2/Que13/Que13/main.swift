//
//  main.swift
//  Que13
//
//  Created by Krushal's Macbook on 28/02/23.
//

import Foundation

//var product = (iphone: "X", price: 1000)
//print(product)         //(iphone: "X", price: 1000) //current value
//product.price = 1200   //Change value
//print(product)         //(iphone: "X", price: 1200) // updated value
//product.iphone = "12 pro"
//product.price = 2000
//print(product)

var stdata = ["Id":"101","name":"krushal","mno":"000000000000"]
print(stdata)
print(stdata.values)
print(stdata.keys)
stdata.updateValue("222", forKey: "Id")
stdata.removeValue(forKey: "mno")
print(stdata)
