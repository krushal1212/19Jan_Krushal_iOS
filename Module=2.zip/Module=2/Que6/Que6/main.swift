//
//  main.swift
//  Que6
//
//  Created by Krushal's Macbook on 24/02/23.
//

print("Enter integer val : ")
var val=Float(readLine()!)!

print("float value is: \(val)")


