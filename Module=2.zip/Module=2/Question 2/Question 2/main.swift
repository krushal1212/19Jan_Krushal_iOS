//
//  main.swift
//  Question 2
//


import Foundation

print("Enter Integer Value : ")

var val:Int
val=Int(readLine()!)!

print("Integer Value : \(val)")
