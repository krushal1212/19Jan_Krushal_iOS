//
//  main.swift
//  Que23
//
//  Created by Krushal's Macbook on 01/03/23.
//

import Foundation

var data = ["aa","bb","cc","dd","ee"]

data.append("f")
print(data)


