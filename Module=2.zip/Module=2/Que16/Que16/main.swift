//
//  main.swift
//  Que16
//
//  Created by Krushal's Macbook on 28/02/23.
//

import Foundation

var ary = ["10","20","30","40"]
print(ary)
ary.insert("90", at: 2)
print(ary)
