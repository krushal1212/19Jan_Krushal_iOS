//
//  main.swift
//  Question 3
//

//

import Foundation

let a=3 // default value a=3

var b=5

print("sum is : \(a+b)")
