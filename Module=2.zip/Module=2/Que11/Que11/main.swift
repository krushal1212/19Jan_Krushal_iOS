//
//  main.swift
//  Que11
//
//  Created by Krushal's Macbook on 27/02/23.
//

import Foundation

print("Enter value of A: ")
var a = Int(readLine()!)!

print("Enter value of B: ")
var b = Int(readLine()!)!

print("Enter value of C: ")
var c = Int(readLine()!)!

if a<b
{
    if a<c {
        print("A is Minimum")
    }
    else {
        print("C is Minimum")
    }
} else {
    if b<c {
        print("B is Minimum")
    }
    else {
        print("C is Minimum")
    }
}
