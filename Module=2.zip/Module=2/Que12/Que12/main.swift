//
//  main.swift
//  Que12
//
//  Created by Krushal's Macbook on 27/02/23.
//

import Foundation

var array = ["ahmedabad","surat","rajkot","baroda","mahesana"]
print("City name :- \(array)")
