//
//  main.swift
//  Que24
//
//  Created by Krushal's Macbook on 01/03/23.
//

import Foundation

var data = ["a","b","c","d","e","f","g"]
print(data)
print("\nEnter Position to Remove : ")

var remove=Int(readLine()!)!
data.remove(at: remove)
print(data)
//data.removeFirst(3)
//print(data)
