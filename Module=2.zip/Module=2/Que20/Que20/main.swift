//
//  main.swift
//  Que20
//
//  Created by Krushal's Macbook on 01/03/23.
//

import Foundation

print("Enter a string 1 : ")
var str1=readLine()!

print("Enter a string 2 : ")
var str2=readLine()!

if str1==str2 {
    print("Both are equal = \(str1) -OR- \(str2)")
}
else {
    print("String are not equal")
}
