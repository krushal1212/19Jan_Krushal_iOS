//
//  ViewController.swift
//  Que-7
//
//  Created by Krushal's Macbook on 03/06/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tbl: UITableView!
    
    var array = ["1","2","3","4","5","6","7","8","9","10",]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl.delegate = self
        self.tbl.dataSource = self
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"TableViewCell", for: indexPath) as! TableViewCell
        cell.lblData.text = array[indexPath.row]
    return cell
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let more = UITableViewRowAction(style: .normal, title: "More", handler: {ACTION, a  in
            print("More button Clicked !!! ")
            let alert = UIAlertController(title: "More", message: "More button Clicked !!! ", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default)
            alert.addAction(ok)
            self.present(alert,animated: true)
        })
        more.backgroundColor = UIColor.brown
        
        let option = UITableViewRowAction(style: .default, title: "Option", handler: {ACTION, a  in
            print("Option button Clicked !!!")
            let alert = UIAlertController(title: "Option", message: "Option button Clicked !!!", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default)
            alert.addAction(ok)
            self.present(alert,animated: true)
        })
        option.backgroundColor = UIColor.systemYellow
        
        let delete = UITableViewRowAction(style: .destructive, title: "Delete", handler: {ACTION, a in
            print("Delete button Clicked !!!")
            let alert = UIAlertController(title: "Delete", message: "Delete button Clicked !!!", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default)
            alert.addAction(ok)
            self.present(alert,animated: true)
        })
        delete.backgroundColor = UIColor.red
        
        return [more, option, delete]
    }
    
}
