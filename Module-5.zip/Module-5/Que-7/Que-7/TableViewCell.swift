//
//  TableViewCell.swift
//  Que-7
//
//  Created by Krushal's Macbook on 05/06/23.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var lblData: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
