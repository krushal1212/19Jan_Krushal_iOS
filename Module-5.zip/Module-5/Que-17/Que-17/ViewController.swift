//
//  ViewController.swift
//  Que-17
//
//  Created by Krushal's Macbook on 03/06/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

