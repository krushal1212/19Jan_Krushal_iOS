//
//  ViewController.swift
//  Que-2
//
//  Created by Krushal's Macbook on 07/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var arrayData = [[""]]
    var arraySection = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
        arrayData = [["vanthali","Manavadar","Keshod"],["puna","adajan","vesu"],["Lodhika","Jasdan","Paddhari","Gondal"],["Mandal","Detroj Rampura.","Viramgam","Daskroi"],["Bhanvad","Dhrol","Jamjodhpur","Jamnagar"]]
        arraySection = ["Junagadh","Surat","Rajkot","Ahmedabad","Jamnagar"]
        self.tblView.delegate = self
        self.tblView.dataSource = self
    }
}
extension ViewController:UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrayData.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData[section].count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.lblData.text! = arrayData[indexPath.section][indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "city name is \(arraySection[section])"
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return "End of \(arraySection[section])"
    }
}
