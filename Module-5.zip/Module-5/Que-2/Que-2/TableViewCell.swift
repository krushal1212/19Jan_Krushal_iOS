//
//  TableViewCell.swift
//  Que-2
//
//  Created by Krushal's Macbook on 07/05/23.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var lblData: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
