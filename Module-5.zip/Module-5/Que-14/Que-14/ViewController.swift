//
//  ViewController.swift
//  Que-14
//
//  Created by Krushal's Macbook on 03/06/23.
//

import UIKit

class ViewController: UIViewController {
    var data: [[String: Any]] = []
    @IBOutlet weak var tbl: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl.delegate = self
        self.tbl.dataSource = self
        
        if let path = Bundle.main.path(forResource: "Info", ofType: "plist"),
           let array = NSArray(contentsOfFile: path) as? [[String: Any]] {
            data = array
            print("=====\(data)=====")
            print("=====\(array)=====")
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.lblTitle.text = data[indexPath.row] 
        return cell
    }
}
