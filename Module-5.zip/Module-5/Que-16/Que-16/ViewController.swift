//
//  ViewController.swift
//  Que-16
//
//  Created by Krushal's Macbook on 03/06/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Check if user is already logged in
        if isLoggedIn() {
            // User is already logged in, proceed to the main screen
            navigateToMainScreen()
        }
    }
    
    @IBAction func loginButtonTapped(_ sender: UIButton) {
        guard let username = usernameTextField.text,
              let password = passwordTextField.text else {
            return
        }
        
        // Perform authentication logic
        if authenticate(username: username, password: password) {
            // User authenticated successfully
            saveLoginStatus()
            navigateToMainScreen()
        } else {
            // Invalid credentials, show error message
            showErrorAlert()
        }
    }
    
    func isLoggedIn() -> Bool {
        return UserDefaults.standard.bool(forKey: "isLoggedIn")
    }
    
    func saveLoginStatus() {
        UserDefaults.standard.set(true, forKey: "isLoggedIn")
    }
    
    func navigateToMainScreen() {
        // Present the main screen or perform any other necessary navigation
    }
    
    func authenticate(username: String, password: String) -> Bool {
        // Perform your authentication logic here
        // This can include checking against a backend server, local database, etc.
        // Return true if the authentication is successful, otherwise false
        return true
    }
    
    func showErrorAlert() {
        // Display an alert to the user indicating invalid credentials
        let alert = UIAlertController(title: "Success", message: "Data Successfully Saved !!!", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default)
        alert.addAction(ok)
        present(alert,animated: true)
    }
}
