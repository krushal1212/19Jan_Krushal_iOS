//
//  ViewController.swift
//  Que-4
//
//  Created by Krushal's Macbook on 08/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    
var array = ["One","Two","Three","Four","Five","Six","Seven","Eight","Nine"]
    var imgData = ["images-1","images-2","images-3","images-4","images-5","images-6","images-7","images-8","images-9"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate = self
        self.tblView.dataSource = self
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        cell.img.image = UIImage(named: imgData[indexPath.row])
        cell.lblData.text = array[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath){
        if editingStyle == .delete{
            array.remove(at: indexPath.row)
            tblView.deleteRows(at: [indexPath], with: .automatic)
            tblView.reloadData()
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
}
