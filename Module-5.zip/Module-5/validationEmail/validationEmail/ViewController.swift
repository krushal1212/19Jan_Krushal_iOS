//
//  ViewController.swift
//  validationEmail
//
//  Created by Krushal's Macbook on 05/06/23.
//

import UIKit
import TextFieldValidator

class ViewController: UIViewController {
    @IBOutlet weak var mobileNumberTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func validateMobileNumber(_ mobileNumber: String) -> Bool {
        let mobileNumberRegex = "^\\d{10}$" // Regular expression pattern for a 10-digit mobile number
        let mobileNumberPredicate = NSPredicate(format: "SELF MATCHES %@", mobileNumberRegex)
        return mobileNumberPredicate.evaluate(with: mobileNumber)
    }
    func validateEmail(_ email: String) -> Bool {
        let emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$" // Regular expression pattern for email validation
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    @IBAction func validateButtonPressed(_ sender: UIButton) {
        guard let mobileNumber = mobileNumberTextField.text, !mobileNumber.isEmpty else {
            showAlert(message: "Please enter a mobile number.")
            return
        }
        
        guard let email = emailTextField.text, !email.isEmpty else {
            showAlert(message: "Please enter an email address.")
            return
        }
        
        if validateMobileNumber(mobileNumber) {
            showAlert(message: "Mobile number is valid.")
        } else {
            showAlert(message: "Invalid mobile number.")
        }
        
        if validateEmail(email) {
            showAlert(message: "Email address is valid.")
        } else {
            showAlert(message: "Invalid email address.")
        }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Validation Result", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }

}

