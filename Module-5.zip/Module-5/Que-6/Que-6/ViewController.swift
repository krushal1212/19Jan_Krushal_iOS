//
//  ViewController.swift
//  Que-6
//
//  Created by Krushal's Macbook on 03/06/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tbl: UITableView!
    
    var array = ["A speaker with an average speaking speed will need 700 words for a 5 minutes speech. A fast speaker will need 850 words for the same speech length. A slow ...","A speaker with an average speaking speed will need 700 words for a 5 minutes speech. A fast speaker will need 850 words for the same speech length. A slow ...A speaker with an average speaking speed will need 700 words for a 5 minutes speech. A fast speaker will need 850 words for the same speech length. A slow ...","A speaker with an average speaking speed"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl.dataSource = self
        self.tbl.delegate = self
    }
}

    extension ViewController: UITableViewDelegate, UITableViewDataSource{
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return array.count
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
            cell.lblTitle.text = array[indexPath.row]
            return cell
        }

    }
