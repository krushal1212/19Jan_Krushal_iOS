//
//  ViewController.swift
//  Que-3
//
//  Created by Krushal's Macbook on 07/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    let data = ["Junagadh", "Rajkot", "Gandhinagar","Surat","Baroda"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate = self
        self.tblView.dataSource = self
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        if indexPath.section == 0{
            cell.lblData.text = data[indexPath.row]
            cell.accessoryType = .disclosureIndicator
        }
        if indexPath.section == 1{
            cell.lblData.text = data[indexPath.row]
            cell.accessoryType = .checkmark
        }
        if indexPath.section == 2{
            cell.lblData.text = data[indexPath.row]
            cell.accessoryType = .detailButton
        }
        if indexPath.section == 3{
            cell.lblData.text = data[indexPath.row]
            cell.accessoryType = .detailDisclosureButton
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        44
    }
    func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
}
