//
//  ViewController.swift
//  Que-5
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var data = ["Junagadh", "Jamnagar", "Rajkot","Surat"]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate = self
        self.tblView.dataSource = self
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.lblData.text! = data[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .insert{
//            let alert = UIAlertController(title: "Add data", message: "Add data", preferredStyle: .alert)
//            let ok = UIAlertAction(title: "OK", style: .default,handler: {(txtusername) in
//
//            })
//            alert.addAction(ok)
//            present(alert,animated: true)
//            tblView.insertRows(at: [indexPath], with: .automatic)
//
//        }
        if editingStyle == .delete {
            data.remove(at: indexPath.row)
            tblView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 66
    }
}
