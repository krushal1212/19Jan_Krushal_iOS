//
//  ViewController.swift
//  Que-5
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var data = ["Junagadh", "Jamnagar", "Rajkot","Surat"]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate = self
        self.tblView.dataSource = self
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.lblData.text! = data[indexPath.row]

//        let dltBtn = UIButton(type: .system)
//        dltBtn.setImage(UIImage(systemName: "trash"), for: .normal)
//        dltBtn.tintColor = .red
//        dltBtn.addTarget(self, action: #selector(deleteItem(_:)), for: .touchUpInside)
//        cell.accessoryView = dltBtn

        return cell
    }
//    @objc func deleteItem(_ sender: UIButton) {
//        let point = sender.convert(CGPoint.zero, to: tblView)
//        guard let indexPath = tblView.indexPathForRow(at: point) else { return }
//        data.remove(at: indexPath.row)
//        tblView.deleteRows(at: [indexPath], with: .automatic)
//    }
}
