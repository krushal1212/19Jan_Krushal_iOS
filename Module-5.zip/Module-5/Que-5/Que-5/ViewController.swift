//
//  ViewController.swift
//  Que-5
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var data = ["Junagadh", "Jamnagar", "Rajkot","Surat"]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate = self
        self.tblView.dataSource = self
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.lblData.text! = data[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {

        if editingStyle == .delete {
            let alert = UIAlertController(title: "Alert", message: "are you sure data is delete???", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Yes", style: .default, handler: {ACTION in
                self.data.remove(at: indexPath.row)
                self.tblView.deleteRows(at: [indexPath], with: .automatic)
            })
            let no = UIAlertAction(title: "No", style: .default, handler: {ACTION in
                self.navigationController?.dismiss(animated: true)
            })
            alert.addAction(ok)
            alert.addAction(no)
            present(alert,animated: true)
            
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 66
    }
}
