//
//  VillageNameVC.swift
//  Que-1
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class VillageNameVC: UIViewController {
    
@IBOutlet weak var tblView: UITableView!
    
    
    var indxUserdflt = UserDefaults.standard.value(forKey: "indxpath")
    var indexPath = 0
    var index0 = ["Bavala","Sanand","Dholera","Dhandhuka","Dholka","Daskroi","Detroj-Rampura","Mandal","Viramgam"]
    var index1 = ["Bagasara","Babra","Rajula","Khambha","Dhari","Lathi","Savarkundla","Liliya","Kukavav"]
    var index2 = ["Moti Monpari","Bhesan","Keshod","Manavadar","Mendarda","Malia-Hatina","Mangrol","Visavadar","Vanthali"]
    var index3 = ["Ankleshwar","Amod","Wagra","Hansot","Jambusar","Netrang","Walia","Jagadia"]
    var index4 = ["Maliya","Miyana","Halwad","Wankaner","Tankara"]
    var index5 = ["Gondal","Dhoraji","Jamkandora","Jetpur","Jasdan","Kotdasangani","Paddhari","Upleta","Lodhika","Vichhiya"]
    var index6 = ["Karjan","Padra","Dabhoi","Savli","Shinor","Dassar","Vaghodia"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tblView.dataSource = self
        self.tblView.delegate = self
    }
    
    @IBAction func btnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
extension VillageNameVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return index2.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VillageTVC") as! VillageTVC
        
        return cell
    }
}
