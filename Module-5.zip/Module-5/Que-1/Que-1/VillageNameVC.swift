//
//  VillageNameVC.swift
//  Que-1
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class VillageNameVC: UIViewController {
    
@IBOutlet weak var tblView: UITableView!
    
    var data = Dictionary<String, Any>()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tblView.dataSource = self
        self.tblView.delegate = self        
    }
    
    @IBAction func btnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
extension VillageNameVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (data["dist"] as? [Any])?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VillageTVC") as! VillageTVC
//        cell.lblVillageName.text = [indexPath.row][""]
        cell.lblVillageName.text = (data["dist"] as? [[String: Any]])?[indexPath.row]["dist"] as? String ?? ""
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "capitalViewController") as! capitalViewController
        vc.villageData = self.data[indexPath.row]
       
        navigationController?.pushViewController(vc, animated: true)
        
    }
}
