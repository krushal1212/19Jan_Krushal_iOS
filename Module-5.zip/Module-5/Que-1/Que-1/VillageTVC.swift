//
//  VillageTVC.swift
//  Que-1
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class VillageTVC: UITableViewCell {
    @IBOutlet weak var lblVillageName:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
