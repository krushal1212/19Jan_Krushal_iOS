//
//  capitalViewController.swift
//  Que-1
//
//  Created by Krushal's Macbook on 11/05/23.
//

import UIKit

class capitalViewController: UIViewController {

    @IBOutlet weak var tblview: UITableView!
    
    var villageData = Dictionary<Any>()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
