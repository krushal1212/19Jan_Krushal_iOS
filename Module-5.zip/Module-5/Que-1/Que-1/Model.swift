//
//  Model.swift
//  Que-1
//
//  Created by Krushal's Macbook on 11/05/23.
//

import Foundation

struct alldata {
    
}
