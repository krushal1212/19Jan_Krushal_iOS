//
//  ViewController.swift
//  Que-1
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    var arrayData = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tblView.delegate = self
        self.tblView.dataSource = self
        tblView.register(UINib(nibName: "TVC", bundle: nil), forCellReuseIdentifier: "TVC")
        
        arrayData = ["Ahmedabad","Amreli","Junagadh","Bharuch","Morbi","Rajkot","Vadodara"]
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC", for: indexPath) as! TVC
        cell.cellView.layer.cornerRadius = 10
        cell.cellView.layer.masksToBounds = true
        cell.lblCityName.text = arrayData[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var VillageNameVC = VillageNameVC()
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "VillageNameVC") as! VillageNameVC
        
        navigationController?.pushViewController(vc, animated: true)
        
    }
}
