//
//  ViewController.swift
//  Que-1
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    var arrayData = [Dictionary<String, Any>]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tblView.delegate = self
        self.tblView.dataSource = self
        
        tblView.register(UINib(nibName: "TVC", bundle: nil), forCellReuseIdentifier: "TVC")
        var arrayDict = [Dictionary<String, Any>]()
        arrayDict.append(["dist": "Ahmedabad", "village": ["Kalol","Dehgam","",""]] as [String: Any])
        arrayDict.append(["dist": "Rajkot", "village": ["Kerali","jetpur","",""]] as [String: Any])
//        let arrayDict: Dictionary = (["dist": "Ahmedabad", "village": ["dehgam","kalol","",""]] as [String: Any])
//        arrayData.append(arrayDict)
        let mainDict: Dictionary = ["name": "Gujarat", "dist": arrayDict] as [String: Any]
        arrayData.append(mainDict)
        
//        let dict: Dictionary = ["city": ["ahmedabad"], "title": "guj"] as [String : Any]
//        arrayData.append(dict)
//        let dict1: Dictionary = ["city": ["udaypur"], "title": "raj"] as [String : Any]
//        arrayData.append(dict1)
//        let dict2: Dictionary = ["city": ["del---"], "title": "del"] as [String : Any]
//        arrayData.append(dict2)
//        let dict3: Dictionary = ["city": ["mp---"], "title": "mp"] as [String : Any]
//        arrayData.append(dict3)
        self.tblView.reloadData()
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC", for: indexPath) as! TVC
        cell.cellView.layer.cornerRadius = 10
        cell.cellView.layer.masksToBounds = true
        cell.lblCityName.text = arrayData[indexPath.row]["name"] as? String ?? ""
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "VillageNameVC") as! VillageNameVC
        vc.data = self.arrayData[indexPath.row]
       
        navigationController?.pushViewController(vc, animated: true)
        
    }
}
