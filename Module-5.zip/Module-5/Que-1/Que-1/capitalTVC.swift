//
//  capitalTVC.swift
//  Que-1
//
//  Created by Krushal's Macbook on 11/05/23.
//

import UIKit

class capitalTVC: UITableViewCell {

    @IBOutlet weak var capital: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
