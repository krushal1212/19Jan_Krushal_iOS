//
//  TVC.swift
//  Que-1
//
//  Created by Krushal's Macbook on 04/05/23.
//

import UIKit

class TVC: UITableViewCell {

    @IBOutlet weak var lblCityName: UILabel!
    @IBOutlet weak var cellView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
