//
//  ViewController.swift
//  COREDATAAPP
//
//  Created by Krushal's Macbook on 03/05/23.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    var alldata = [Studinfo]()
    @IBOutlet weak var mytb: UITableView!
    @IBOutlet weak var mobile: UITextField!
    @IBOutlet weak var subject: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        print(path)
    }

    @IBAction func btn(_ sender: Any) {
        getdata()
        displaydata()
    }
    
    func displaydata(){
        
    }
    
    
    
    func getdata() {
        let stdata = ["name":name.text!,"email":email.text!,"subject":subject.text!,"mobile":Int(mobile.text!)!] as [String : Any]
        let dml = DMLOperrations()
        dml.savedata(data: stdata)
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alldata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        cell.textLabel?.text = alldata[indexPath.row].name
        cell.detailTextLabel?.text = alldata[indexPath.row].subject
        return cell
    }
    
    
}
