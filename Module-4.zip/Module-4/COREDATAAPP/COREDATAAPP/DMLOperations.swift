//
//  DMLOperations.swift
//  COREDATAAPP
//
//  Created by Krushal's Macbook on 03/05/23.
//

import Foundation
import CoreData
import UIKit


class DMLOperrations {
    
    func savedata(data:[String:Any]) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let it = NSEntityDescription.insertNewObject(forEntityName: "Studinfo", into: context) as! Studinfo
        it.name = data["name"] as? String
        it.email = data["email"] as? String
        it.subject = data["subject"] as? String
        it.mobile = Int64(data["mobile"] as! Int)
        
    }
    
    func showdata()->[Studinfo] {
        
        
        
        var stdata = [Studinfo]()
        let req = NSFetchRequest<NSManagedObject>.init(entityName: "Studinfo")
        
        do {
            stdata = try context.fetch(req)
        }
        catch {
            print(error.localizedDescription)
        }
    }
    
}
