//
//  ViewController.swift
//  Que-15
//
//  Created by Krushal's Macbook on 29/04/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var countryPicker: UIPickerView!
    
    @IBOutlet var CountryView: UIView!
    
    @IBOutlet weak var StateView: UIView!
    
    @IBOutlet weak var statePicker: UIPickerView!
    var countryname = ["India","Russia","Canada","China","America","Brazil","Australia","Argentina"]
    var stateName = ["HARYANA","UTTAR PRADESH","TRIPURA","GUJARAT","UTTARAKHAND","JHARKHAND","GOA","LADAKH"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        CountryView.isHidden = false
        StateView.isHidden = true
        countryPicker.delegate = self
        countryPicker.dataSource = self
        
    }
}

extension ViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
       
        if CountryView.isHidden == false{
            StateView.isHidden = true
        }else {
            CountryView.isHidden = true
            StateView.isHidden = false
        }
        return 1
//        if (countryPicker != nil){
//            StateView.isHidden = true
//            return 1
//        }else {
//            StateView.isHidden = false
//            CountryView.isHidden = true
//            return 1
//        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0{
            return countryname.count
        }else {
            return stateName.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return countryname[row]
        }else{
            return stateName[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let alert = UIAlertController(title: "Your Contry Name", message: countryname[row], preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { ACTION in
            self.CountryView.isHidden = true
            self.StateView.isHidden = false
        })
        alert.addAction(ok)
        present(alert,animated: true)
        return
    }
}
