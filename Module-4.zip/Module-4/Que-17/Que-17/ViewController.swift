//
//  ViewController.swift
//  Que-17
//
//  Created by Krushal's Macbook on 02/05/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set the title of the navigation bar
        navigationItem.title = "Custom Navigation Bar"
        
        // Set the background color of the navigation bar
        navigationController?.navigationBar.barTintColor = .systemBlue
        
        // Set the tint color of the navigation bar buttons
        navigationController?.navigationBar.tintColor = .white
        
        // Set the color of the title text in the navigation bar
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        // Set the style of the navigation bar
        navigationController?.navigationBar.barStyle = .black
        
        // Set the transparency of the navigation bar
        navigationController?.navigationBar.isTranslucent = true
        
        // Hide the navigation bar shadow
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        
        // Customize the back button appearance
        let backButtonImage = UIImage(systemName: "chevron.left")?.withTintColor(.white, renderingMode: .alwaysOriginal)
        navigationController?.navigationBar.backIndicatorImage = backButtonImage
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = backButtonImage
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}

