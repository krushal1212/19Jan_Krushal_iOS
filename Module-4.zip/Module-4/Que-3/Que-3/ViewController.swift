//
//  ViewController.swift
//  Que-3
//
//  Created by Krushal's Macbook on 12/04/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtUser: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var lblPass: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblUser.textAlignment = .center
        lblPass.textAlignment = .center
        lblUser.isHidden = true
        lblPass.isHidden = true
    }
    
    @IBAction func btnLogin1(_ sender: Any) {
        if txtUser.text == "" || txtPass.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Data is Empty !!!", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default)
            alert.addAction(ok)
            present(alert,animated: true)
        }else {
            let alert = UIAlertController(title: "Success", message: "User Successfully Login !!!", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default,handler: { ACTION in
                self.lblUser.isHidden = false
                self.lblPass.isHidden = false
            })
            alert.addAction(ok)
            present(alert,animated: true)
            
        }
        
        self.lblUser.text = self.txtUser.text
        self.lblPass.text = self.txtPass.text
    }
}

