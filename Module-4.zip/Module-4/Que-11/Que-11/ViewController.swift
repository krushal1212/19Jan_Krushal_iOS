//
//  ViewController.swift
//  Que-11
//
//  Created by Krushal's Macbook on 24/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var pickerView: UIPickerView!
    
    var course = [""]
    var city = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
        course = ["PHP","Python","Java","iOS","Flutter","Android",".net","web developing"]
        city = ["Rajkot","Junagdh","Ahmedabad","Surat","Jamnagar","Porbandar","Baroda","Bharuch"]
        pickerView.delegate = self
        pickerView.dataSource = self
    }
}
extension ViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0{
            return course.count
        }else{
            return city.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0{
            return course[row]
        }else{
            return city[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {

        if component == 1 {
            let selectCourse = course[row]
            print("My course is \(selectCourse).")
        }else {
            let selectCity = city[row]
            print("My city is \(selectCity).")
        }
    }
}
