//
//  ViewController.swift
//  Que-4
//
//  Created by Krushal's Macbook on 12/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblHeader: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        lblHeader.isHidden = false
    }
    @IBAction func showlbl(_ sender: Any) {
        lblHeader.isHidden = false
    }
    
    @IBAction func hidelbl(_ sender: Any) {
        lblHeader.isHidden = true
    }
    
}

