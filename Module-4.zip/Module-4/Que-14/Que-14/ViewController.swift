//
//  ViewController.swift
//  Que-14
//
//  Created by Krushal's Macbook on 25/04/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var txtDate: UITextField!
    @IBOutlet weak var txtCurrentDate: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtDate.textAlignment = .center
        txtCurrentDate.textAlignment = .center
    }
    
    @IBAction func dateChanger(_ sender: Any)
    {
        let selectedDate = datePicker.date
        let currentDate = Date()
        let dftr = DateFormatter()
        dftr.dateStyle = .medium
        dftr.timeStyle = .medium
        txtDate.text = "Selected Date - \(dftr.string(from: selectedDate))"
        txtCurrentDate.text = "Current Date - \(dftr.string(from: currentDate))"
    }
}

