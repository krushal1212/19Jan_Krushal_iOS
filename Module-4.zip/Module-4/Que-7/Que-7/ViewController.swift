//
//  ViewController.swift
//  Que-7
//
//  Created by Krushal's Macbook on 20/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func btnImg1(_ sender: Any)
    {
        
    }
    @IBAction func btnimg2(_ sender: Any)
    {
        
    }
    @IBAction func btnimg3(_ sender: Any)
    {
        
    }
}

