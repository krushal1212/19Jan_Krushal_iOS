//
//  SelectImgVC.swift
//  Que-7
//
//  Created by Krushal's Macbook on 20/04/23.
//

import UIKit

class SelectImgVC: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    
    var selectedImageView: UIImageView?
    var imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        
        btn1.setTitle("Add Image", for: .normal)
        btn2.setTitle("Add Image", for: .normal)
        btn3.setTitle("Add Image", for: .normal)
    }
    
    @IBAction func btn1(_ sender: Any)
    {
        selectedImageView = img1
        showImagePicker()
        btn1.setTitleColor(.clear, for: .normal)
    }
    @IBAction func btn2(_ sender: Any)
    {
        selectedImageView = img2
        
        showImagePicker()
        btn2.setTitleColor(.clear, for: .normal)
    }
    @IBAction func btn3(_ sender: Any)
    {
        selectedImageView = img3
        showImagePicker()
        btn3.setTitleColor(.clear, for: .normal)
    }
    func showImagePicker() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            selectedImageView?.image = image
        }
        dismiss(animated: true, completion: nil)
    }
}
