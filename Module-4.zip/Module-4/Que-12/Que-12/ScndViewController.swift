//
//  ScndViewController.swift
//  Que-12
//
//  Created by Krushal's Macbook on 25/04/23.
//

import UIKit

class ScndViewController: UIViewController {
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var lblDate: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func changeDate(_ sender: UIDatePicker)
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .full
        lblDate.text = dateFormatter.string(from: sender.date)
    }
}
