//
//  ViewController.swift
//  Que-12
//
//  Created by Krushal's Macbook on 24/04/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tbl: UITableView!
    var dataSubTitle = [""]
    var img = [UIImage]()
    var dataTitle = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tbl.delegate = self
        self.tbl.dataSource = self
        
        tbl.estimatedRowHeight = 80.0
        tbl.rowHeight = UITableView.automaticDimension
        
//        img = [UIImage(named: "1"), UIImage(named: "2"), UIImage(named: "3"), UIImage(named: "4"), UIImage(named: "5"), UIImage(named: "6"), UIImage(named: "7")]
        img = [UIImage(imageLiteralResourceName: "1"),UIImage(imageLiteralResourceName: "2"),UIImage(imageLiteralResourceName: "3"),UIImage(imageLiteralResourceName: "4"),UIImage(imageLiteralResourceName: "5"),UIImage(imageLiteralResourceName: "6"),UIImage(imageLiteralResourceName: "7")]
        dataTitle = ["iOS","Python","PHP","Android","SQL","React","JAVA"]
        dataSubTitle = ["Same as UIImagePickerController and sorce code given below is working fine but it get only video file not audio file i pick only audio file:","Thanks in advance..","You can't retrieve audio files using UIImagePicker,","hello if there are to posible to select audio file select same as UIImagePickerController","Hello sir,How to get list of audio file from gallery in ios ","when download song from whatsapp application that is store in gallery in iPhone how to get that list of song in UIImagePickerView or any other option to view it.."]
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSubTitle.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC", for: indexPath) as! TVC
        cell.lblTitleCell.text = dataTitle[indexPath.row]
        cell.lblSubTitleCell.text = dataSubTitle[indexPath.row]
        cell.imgCell.image = img[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "FinalDataVC") as! FinalDataVC
        vc.titleData = dataTitle[indexPath.row]
        vc.subTitleData = dataSubTitle[indexPath.row]
        vc.imgData = img[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
}
