//
//  FinalDataVC.swift
//  Que-12
//
//  Created by Krushal's Macbook on 25/04/23.
//

import UIKit

class FinalDataVC: UIViewController {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubTitle: UILabel!
    var titleData = ""
    var subTitleData = ""
    var imgData = UIImage()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.backBarButtonItem?.isHidden = true
        
        img.image = imgData
        lblTitle.text = titleData
        lblSubTitle.text = subTitleData
    }
}
