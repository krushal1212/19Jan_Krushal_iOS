//
//  TVC.swift
//  Que-12
//
//  Created by Krushal's Macbook on 24/04/23.
//

import UIKit

class TVC: UITableViewCell {

    @IBOutlet weak var lblTitleCell: UILabel!
    @IBOutlet weak var imgCell: UIImageView!
    @IBOutlet weak var lblSubTitleCell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
