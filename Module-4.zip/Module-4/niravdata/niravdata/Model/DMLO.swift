//
//  DMLO.swift
//  niravdata
//
//  Created by Krushal's Macbook on 03/05/23.
//

import Foundation
import CoreData
import UIKit

class DMLOperation {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func savedata(data:[String:Any]) {
        let it = NSEntityDescription.insertNewObject(forEntityName: "Studinfo", into: context) as! Studinfo
        it.name = data["name"] as? String
        it.email = data["email"] as? String
        it.subject = data["subject"] as? String
        it.mobile = Int64(data["mobile"] as! Int)
        
        
        
    }
}
