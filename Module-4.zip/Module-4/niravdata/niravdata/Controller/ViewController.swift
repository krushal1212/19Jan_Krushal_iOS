//
//  ViewController.swift
//  niravdata
//
//  Created by Krushal's Macbook on 03/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txt_mobile: UITextField!
    @IBOutlet weak var txt_subject: UITextField!
    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var txt_name: UITextField!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let dml = DMLOperation()
    override func viewDidLoad() {
        super.viewDidLoad()
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .allDomainsMask, true)
        print(path)
        
    }

    @IBAction func btn_show(_ sender: Any) {
        showdt()
    }
    func showdt() {
        let SecondViewController=storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        navigationController?.pushViewController(SecondViewController, animated: true)
    }
    
    @IBAction func btn_save(_ sender: Any) {
        displaydata()
    }
    
    func displaydata() {
        
        let stdata = ["name":txt_name.text!
                      ,"email":txt_email.text!,
                      "subject":txt_subject.text!,
                      "mobile":Int(txt_mobile.text!)!] as [String : Any]
        dml.savedata(data: stdata)
        
        do {
            try context.save()
        } catch {
            print(error.localizedDescription)
        }
        
    }
    
    @IBAction func btn_update(_ sender: Any) {
        
    }
}

