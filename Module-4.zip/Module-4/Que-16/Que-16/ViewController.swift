//
//  ViewController.swift
//  Que-16
//
//  Created by Krushal's Macbook on 02/05/23.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var txtData: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtData.delegate = self
        hideKeyboardTap()
    }
        func hideKeyboardTap() {
            let tapGesture = UITapGestureRecognizer(target: self,
                             action: #selector(hideKeyboard))
            view.addGestureRecognizer(tapGesture)
        }
    
        @objc func hideKeyboard() {
            view.endEditing(true)
        }
    @IBAction func shareButtonTapped(_ sender: UIButton) {
        
        if txtData.text!.isEmpty{
            let alert = UIAlertController(title: "Error", message: "Please enter your name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }else {
            
            let txtShare = txtData.text
            let vc = UIActivityViewController(activityItems: [txtShare ?? "No data"], applicationActivities: nil)
            present(vc, animated: true, completion: nil)
        }
    }
}

