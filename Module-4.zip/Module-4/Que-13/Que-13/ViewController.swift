//
//  ViewController.swift
//  Que-13
//
//  Created by Krushal's Macbook on 25/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var clrPicker: UIPickerView!
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    var clrName1 = ["Blue","Black","Orange","Yellow","Green","Purple","Red","Brown"]
    var clrName2 = ["Black","Green","Blue","Orange","Purple","Brown","Yellow","Red"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        clrPicker.delegate = self
        clrPicker.dataSource = self
        clrPicker.backgroundColor = UIColor.clear
        
    }
}

extension ViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0{
            return clrName1.count
        }else{
            return clrName2.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0{
            return clrName1[row]
        }else{
            return clrName2[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
//        ["Blue","Black","Orange","Yellow","Green","Purple","Red","Brown"]
        if component == 0{
            switch clrName1[row] {
            case "Blue":
                view1.backgroundColor = UIColor.blue
            case "Black":
                view1.backgroundColor = UIColor.black
            case "Orange":
                view1.backgroundColor = UIColor.orange
            case "Yellow":
                view1.backgroundColor = UIColor.yellow
            case "Purple":
                view1.backgroundColor = UIColor.purple
            case "Red":
                view1.backgroundColor = UIColor.red
            case "Brown":
                view1.backgroundColor = UIColor.brown
            case "Green":
                view1.backgroundColor = UIColor.green
            default:
                view1.backgroundColor = UIColor.clear
            }
        }else {
            switch clrName2[row] {
            case "Blue":
                view2.backgroundColor = UIColor.blue
            case "Black":
                view2.backgroundColor = UIColor.black
            case "Orange":
                view2.backgroundColor = UIColor.orange
            case "Yellow":
                view2.backgroundColor = UIColor.yellow
            case "Purple":
                view2.backgroundColor = UIColor.purple
            case "Red":
                view2.backgroundColor = UIColor.red
            case "Brown":
                view2.backgroundColor = UIColor.brown
            case "Green":
                view2.backgroundColor = UIColor.green
            default:
                view2.backgroundColor = UIColor.clear
            }
        }
    }
}
