//
//  ViewController.swift
//  Que-5
//
//  Created by Krushal's Macbook on 14/04/23.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnAlert(_ sender: Any) {
        
        let alertt = UIAlertController(title: "Enter Values", message: "", preferredStyle: .alert)
        
        alertt.addTextField { (textField) in
            textField.placeholder = "Username"
        }
        
        alertt.addTextField { (textField) in
            textField.placeholder = "Password"
        }
        
        let cancle = UIAlertAction(title: "Cancle", style: .cancel)
        let ok = UIAlertAction(title: "OK", style: .default,handler: { ACTION in
            if let firstName = alertt.textFields?[0].text, let lastName = alertt.textFields?[1].text {
                       print("First Name: \(firstName), Last Name: \(lastName)")
                   }
            let vc1 = self.storyboard?.instantiateViewController(withIdentifier: "DataViewController") as! DataViewController
            vc1.data1 = alertt.textFields?[0].text ?? ""
            vc1.data2 = alertt.textFields?[1].text ?? ""
            self.navigationController?.pushViewController(vc1, animated: true)
            
        })
        
        alertt.addAction(ok)
        alertt.addAction(cancle)
        present(alertt, animated: true)
    }
    
}

