//
//  DataViewController.swift
//  Que-5
//
//  Created by Krushal's Macbook on 15/04/23.
//

import UIKit

class DataViewController: UIViewController {

    @IBOutlet weak var lblOne: UILabel!
    @IBOutlet weak var lblTwo: UILabel!
    
    var data1 = ""
    var data2 = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblOne.text = data1
        lblTwo.text = data2
    }
}
