//
//  ViewController.swift
//  Que-6
//
//  Created by Krushal's Macbook on 12/04/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

