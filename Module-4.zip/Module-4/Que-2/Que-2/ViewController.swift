//
//  ViewController.swift
//  Que-2
//
//  Created by Krushal's Macbook on 12/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func btnLogin(_ sender: UIButton) {
        if txtUsername.text == "" || txtPassword.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Data is Empty !!!", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default)
            alert.addAction(ok)
            present(alert,animated: true)
        }else {
            let alert = UIAlertController(title: "Success", message: "User Successfully Login !!!", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default)
            alert.addAction(ok)
            present(alert,animated: true)
        }
    }
}

