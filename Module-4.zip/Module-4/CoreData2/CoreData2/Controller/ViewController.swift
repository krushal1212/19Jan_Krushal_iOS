//
//  ViewController.swift
//  CoreData2
//
//  Created by Krushal's Macbook on 03/05/23.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func btn_save(_ sender: Any) {
        
    }
    
    @IBAction func btn_show(_ sender: Any) {
        
    }
    
    @IBAction func btn_update(_ sender: Any) {
        
    }
}

