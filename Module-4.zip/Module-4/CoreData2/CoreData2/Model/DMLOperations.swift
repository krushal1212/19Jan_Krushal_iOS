//
//  DMLOperations.swift
//  CoreData2
//
//  Created by Krushal's Macbook on 03/05/23.
//

import Foundation
import CoreData
import UIKit

class DMLOperation {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
}
