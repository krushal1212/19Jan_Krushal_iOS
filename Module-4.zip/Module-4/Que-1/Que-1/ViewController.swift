//
//  ViewController.swift
//  Que-1
//
//  Created by Krushal's Macbook on 11/04/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

