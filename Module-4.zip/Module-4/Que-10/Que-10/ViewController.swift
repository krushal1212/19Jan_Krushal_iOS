//
//  ViewController.swift
//  Que-10
//
//  Created by Krushal's Macbook on 24/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func dateChange(_ sender: UIDatePicker) {

        let dateFormater = DateFormatter()
        dateFormater.dateStyle = .long
        lblDate.text = dateFormater.string(from: sender.date)
        
    }
}

