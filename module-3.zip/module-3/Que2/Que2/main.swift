//
//  main.swift
//  Que2
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var array = ["id":"1","Name":"Krushal","city":"Junagadh"]
print(array["city"]!)

