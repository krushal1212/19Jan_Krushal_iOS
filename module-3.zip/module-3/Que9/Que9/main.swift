//
//  main.swift
//  Que9
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

class student: NSObject {
    func data(id:Int) {
        print("student id :", id)
    }
}

class secondstudent: student {
    func data(id: Int,name:String) {
        print("Second student id :", id)
        print("S student name :",name)
    }
    override func data(id: Int) {
        print("Third student id :", id)
        
    }
}


var st = student()
st.data(id: 101)

var result = secondstudent()
result.data(id: 202, name: "Krushal")
result.data(id: 401)



