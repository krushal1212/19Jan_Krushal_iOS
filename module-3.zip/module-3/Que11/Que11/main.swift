//
//  main.swift
//  Que11
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

protocol value {
    func getdata(id: Int, name: String)
    func getcity(City : String)
}


class data: value {
    func getdata(id: Int, name: String) {
        print("id is :", id)
        print("Name is :", name)
    }
    
    func getcity(City: String) {
        print("City name is : ", City)
    }
}

var dt = data()
dt.getdata(id: 10, name: "Krushal")
dt.getcity(City: "Ahmedabad")
