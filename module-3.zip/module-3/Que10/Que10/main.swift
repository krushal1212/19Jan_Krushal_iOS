//
//  main.swift
//  Que10
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

struct bankDetails {
    var accnm : String
    var accmo : Double
    var accbal : Double
    var accno : Double
    var accem : String
}
var user1 = bankDetails(accnm: "aaa", accmo: 8966, accbal: 567, accno: 25896, accem: "hfujf")
var user2 = bankDetails(accnm: "bbb", accmo: 234, accbal: 8790, accno: 21342, accem: "fhdted")
var user3 = bankDetails(accnm: "ccc", accmo: 23421, accbal: 2345, accno: 245, accem: "ljlawd")
var user4 = bankDetails(accnm: "ddd", accmo: 235, accbal: 679676, accno: 671243, accem: "dsvatj")
var user5 = bankDetails(accnm: "eee", accmo: 2343, accbal: 565477, accno: 25892136, accem: "sdagrht")
var user6 = bankDetails(accnm: "fff", accmo: 1238, accbal: 23235, accno: 1234, accem: "ksytjty")
var user7 = bankDetails(accnm: "ggg", accmo: 235, accbal: 8934, accno: 2355, accem: "dfbhrh")
var user8 = bankDetails(accnm: "hhh", accmo: 462346, accbal: 3463, accno: 3413, accem: "adsaef")
var user9 = bankDetails(accnm: "iii", accmo: 21342, accbal: 8965, accno: 56941, accem: "fgbsw")
var user10 = bankDetails(accnm: "jjj", accmo: 4346, accbal: 5646469, accno: 45321, accem: "ljpaef")

print(user1)
print(user2)
print(user3)
print(user4)
print(user5)
print(user6)
print(user7)
print(user8)
print(user9)
print(user9)
