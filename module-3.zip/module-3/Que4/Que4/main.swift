//
//  main.swift
//  Que4
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var value0 = 0
var value1 = 23
var value2 = 66

print("Value 1 = ",value1)
print("Value 2 = ",value2)

value0 = value1
value1 = value2
value2 = value0

print("\nvalue 1 = ",value1)
print("value 2 = ",value2)
