//
//  main.swift
//  Que5
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var city = ["surat","ahmedabad","rajkot","junagadh"]

city.sort()
print(city)
