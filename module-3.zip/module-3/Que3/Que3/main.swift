//
//  main.swift
//  Que3
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation
class st: NSObject {
    
    func contain(input: String)->Bool{
        for char in input {
            if (!(char >= "a" && char <= "z") && !(char >= "A" && char <= "Z")) {
                return false
            }
        }
        return true
    }
}
